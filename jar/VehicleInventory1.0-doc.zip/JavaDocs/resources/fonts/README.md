# DejaVu web fonts

This [repository](https://github.com/VorpalBlade/dejavu-webfonts) contains the [DejaVu fonts](https://dejavu-fonts.github.io/) as web fonts.

This is DejaVu fonts version 2.37.

Converted using [ttf2woff](https://github.com/fontello/ttf2woff) and
[woff2](https://github.com/google/woff2).
