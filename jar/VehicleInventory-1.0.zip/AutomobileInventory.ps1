#!/bin/bash
java -jar VehicleInventory-1.0.jar
