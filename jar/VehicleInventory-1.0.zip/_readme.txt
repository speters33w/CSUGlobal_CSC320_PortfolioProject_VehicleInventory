The following files need to be present in the same directory as the jar to run this program:

bak (directory)
auto_brands_us.list
autos.adb

The program is best run on a terminal with ANSI support, use PowerShell 7 (Windows) or [almost] any Linux terminal.

Run the program with the following command:
java -jar VehicleInventory-1.0.jar

Run the test pogram with the following command:
java -cp VehicleInventory-1.0.jar TestAutomobile